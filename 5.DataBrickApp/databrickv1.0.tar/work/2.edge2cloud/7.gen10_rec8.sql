insert into smssuser.tbl_sm_data(time_stamp, sensor_id, 
site_id, building_id, floor_id, sector_id,sensor_unit_id, value_col_1) 
values(sysdate, 8,1,1,1,1,1, 32);

insert into smssuser.tbl_sm_data(time_stamp, sensor_id, 
site_id, building_id, floor_id, sector_id,sensor_unit_id, value_col_1) 
values(sysdate, 8,1,1,1,1,1, 28);

insert into smssuser.tbl_sm_data(time_stamp, sensor_id, 
site_id, building_id, floor_id, sector_id,sensor_unit_id, value_col_1) 
values(sysdate, 8,1,1,1,1,1, 31);

insert into smssuser.tbl_sm_data(time_stamp, sensor_id, 
site_id, building_id, floor_id, sector_id,sensor_unit_id, value_col_1) 
values(sysdate, 8,1,1,1,1,1, 23);

insert into smssuser.tbl_sm_data(time_stamp, sensor_id, 
site_id, building_id, floor_id, sector_id,sensor_unit_id, value_col_1) 
values(sysdate, 8,1,1,1,1,1, 35);

insert into smssuser.tbl_sm_data(time_stamp, sensor_id, 
site_id, building_id, floor_id, sector_id,sensor_unit_id, value_col_1) 
values(sysdate, 8,1,1,1,1,1, 31);

insert into smssuser.tbl_sm_data(time_stamp, sensor_id, 
site_id, building_id, floor_id, sector_id,sensor_unit_id, value_col_1) 
values(sysdate, 8,1,1,1,1,1, 31);

insert into smssuser.tbl_sm_data(time_stamp, sensor_id, 
site_id, building_id, floor_id, sector_id,sensor_unit_id, value_col_1) 
values(sysdate, 8,1,1,1,1,1, 32);

insert into smssuser.tbl_sm_data(time_stamp, sensor_id, 
site_id, building_id, floor_id, sector_id,sensor_unit_id, value_col_1) 
values(sysdate, 8,1,1,1,1,1, 29);

insert into smssuser.tbl_sm_data(time_stamp, sensor_id, 
site_id, building_id, floor_id, sector_id,sensor_unit_id, value_col_1) 
values(sysdate, 8,1,1,1,1,1, 30);
