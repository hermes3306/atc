rsh db@pc1 /home/db/ab72/bin/startdb.sh 
rsh db@pc2 /home/db/ab72/bin/startdb.sh 
rsh db@pc3 /home/db/ab72/bin/startdb.sh 
rsh db@pc4 /home/db/ab72/bin/startdb.sh 
rsh db@pc5 /home/db/ab72/bin/startdb.sh 
rsh db@pc6 /home/db/ab72/bin/startdb.sh 
rsh db@pc7 /home/db/ab72/bin/startdb.sh 
rsh db@pc8 /home/db/ab72/bin/startdb.sh 
rsh db@pc0 /home/db/ab72/bin/startdb.sh 
rsh db@pc9 /home/db/ab72/bin/startdb.sh 

