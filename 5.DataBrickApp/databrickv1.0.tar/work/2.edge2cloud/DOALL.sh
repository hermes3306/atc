./1.crtuser.sh
./2.genschema.sh
./4.crt_src_rep.sh
./5.crt_tar_rep.sh
./6.start_src_rep.sh
./7.gen10record.sh
./B.sh
