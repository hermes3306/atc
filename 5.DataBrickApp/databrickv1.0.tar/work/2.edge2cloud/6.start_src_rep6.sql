alter replication rep6 start;
