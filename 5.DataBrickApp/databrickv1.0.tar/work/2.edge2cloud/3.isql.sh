isql -u SMSSUSER -p SMSSUSER  -s $1
