select count(*) from TBL_SM_DATA;
