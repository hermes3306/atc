isql -u sys -p manager -s pc0 < 5.crt_tar_rep.sql
