alter replication rep10 start;
